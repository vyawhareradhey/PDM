package com.pdm.service;

import com.pdm.core.Folder;
import com.pdm.core.SessionContext;
import com.pdm.core.User;
import com.pdm.dao.FolderDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FolderService {
    private FolderDAO folderDAO;

    public FolderService() {
        this.folderDAO = new FolderDAO();
    }

    public boolean createFolder(String name, Folder parent) {
        User currentUser = SessionContext.getInstance().getCurrentUser();
        if (currentUser == null) return false;
        
        Integer parentId = (parent != null && parent.getId() > 0) ? parent.getId() : null;
        
        try {
            return folderDAO.createFolder(name, parentId, currentUser.getId()) != -1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Folder> getFolderStructure() {
        try {
            // MVP: Eager loading (ok for small data)
            // 1. Get Roots
            List<Folder> roots = folderDAO.getRootFolders();
            for (Folder root : roots) {
                loadRecursive(root);
            }
            return roots;
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    private void loadRecursive(Folder parent) throws SQLException {
        List<Folder> subs = folderDAO.getSubFolders(parent.getId());
        for (Folder sub : subs) {
            parent.addSubFolder(sub);
            loadRecursive(sub);
        }
    }

    public Folder getUserHomeFolder() {
        User user = SessionContext.getInstance().getCurrentUser();
        if (user == null) return null;
        try {
            List<Folder> roots = folderDAO.getRootFolders();
            for (Folder f : roots) {
                if (f.getOwnerId() == user.getId() && "Home".equalsIgnoreCase(f.getName())) {
                    return f;
                }
            }
            // If not found, create one
            int id = folderDAO.createFolder("Home", null, user.getId());
            if (id != -1) {
                return new Folder(id, "Home", 0, user.getId());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Folder> getAllFolders() {
        List<Folder> result = new ArrayList<>();
        List<Folder> roots = getFolderStructure();
        flattenFolders(roots, result);
        return result;
    }
    
    private void flattenFolders(List<Folder> list, List<Folder> result) {
        for (Folder f : list) {
            result.add(f);
            flattenFolders(f.getSubFolders(), result);
        }
    }

    public boolean renameFolder(int folderId, String newName) {
        if (newName == null || newName.trim().isEmpty()) return false;
        try {
            return folderDAO.renameFolder(folderId, newName.trim());
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteFolder(int folderId) {
        try {
            return folderDAO.deleteFolder(folderId);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
